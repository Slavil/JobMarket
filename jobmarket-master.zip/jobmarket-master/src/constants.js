exports.DB_CONNECTION_STRING = 'mongodb://localhost:27017/job-ads'
exports.JWT_SECRET = '683F64567242B37F76BD633899384' // code from randomkeygen.com
exports.AUTH_COOKIE_NAME = 'token'