const AdModel = require("../models/ad.js");
const userService = require("./userService.js");

const getFirstThree = () => {
  return AdModel.find().limit(3).lean();
};

const create = (data) => {
  return AdModel.create(data);
};

const getAll = () => {
  return AdModel.find({}).lean();
};

const getOne = (id) => {
  return AdModel.findById(id).populate("usersApplied").populate("author").lean();
};

const updateOne = (id, data) => {
  return AdModel.findByIdAndUpdate(id, data, { runValidators: true, new: true });
};

const deleteOne = (id) => {
  return AdModel.findByIdAndDelete(id);
};

const apply = async (adId, user) => {
  const ad = await AdModel.findById(adId);
  console.log(user.id);
  ad.usersApplied.push(user.id);
  await userService.applyForAdd(adId, user.id);
  return ad.updateOne({ $set: { usersApplied: ad.usersApplied } });
};

const search = async (typeStr) => {
  console.log(typeStr);
  const regEx = new RegExp(typeStr, "i");

  const ads = await AdModel.find().populate("author");
  return ads.filter((x) => regEx.test(x.author.email));
};

const adService = { getFirstThree, create, getAll, getOne, updateOne, deleteOne, apply, search };

module.exports = adService;
