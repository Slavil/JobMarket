1. Must have installed node.js
2. Open project folder with VS Code, open terminal and run npm install
3. Open index.js and run with node.js
4. App will be running on http://localhost:3000